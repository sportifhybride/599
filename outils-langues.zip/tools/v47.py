# -*- coding: utf-8 -*-
"""v47 : applique les modifications de contenu au site FR (idempotent) et ecrit les traductions."""
import re, os, json, sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
SITE = '../site'
TR = []   # (fr, en, es)
def T(fr, en, es):
    TR.append((fr, en, es)); return fr
def rd(f): return open(f'{SITE}/{f}', encoding='utf8').read()
def wr(f, s): open(f'{SITE}/{f}', 'w', encoding='utf8').write(s)
def swap_main(f, new):
    s = rd(f); s2 = re.sub(r'<main.*?</main>', lambda m: new, s, count=1, flags=re.S); wr(f, s2)

en0 = json.load(open('en.json')); es0 = json.load(open('es.json'))
sys.path.insert(0, '.')
from extras import EXACT as EX0
for fr, e, s in EX0: en0.setdefault(fr, e); es0.setdefault(fr, s)

def eur(n):
    return (f'{n:g}'.replace('.', ',')) if n == int(n) else f'{n:.2f}'.replace('.', ',')
def eur_en(n):
    return f'€{n:g}' if n == int(n) else f'€{n:.2f}'

# ---------- blocs communs ----------
def formules():
    return ('<section class="formules"><h2>' + T('Deux formules pour chaque programme', 'Two options for every program', 'Dos fórmulas para cada programa') + '</h2><div class="fcols">'
      '<div class="fcol"><h4>' + T('SANS SUIVI', 'WITHOUT FOLLOW-UP', 'SIN SEGUIMIENTO') + '</h4><p>' +
      T("Tu reçois ton programme en PDF et tu t'entraînes en autonomie.", 'You receive your program as a PDF and train on your own.', 'Recibes tu programa en PDF y entrenas de forma autónoma.') + '</p></div>'
      '<div class="fcol on"><h4>' + T('AVEC SUIVI · +5 €', 'WITH FOLLOW-UP · +€5', 'CON SEGUIMIENTO · +5 €') + '</h4><p>' +
      T('Tu reçois le PDF, un Google Sheet de suivi et un contact régulier avec moi sur WhatsApp :', 'You receive the PDF, a Google Sheet to track your sessions and regular contact with me on WhatsApp:', 'Recibes el PDF, una hoja de Google para el seguimiento y un contacto regular conmigo por WhatsApp:') + '</p><ul>'
      '<li>' + T('Charges conseillées pour tes prochaines séances', 'Recommended loads for your next sessions', 'Cargas recomendadas para tus próximas sesiones') + '</li>'
      '<li>' + T('Conseils après chaque séance', 'Advice after each session', 'Consejos después de cada sesión') + '</li>'
      '<li>' + T('Adaptation des charges selon ta fatigue', 'Loads adjusted to your fatigue', 'Ajuste de las cargas según tu fatiga') + '</li>'
      '<li>' + T('Retours par le Sheet ou par message', 'Feedback through the Sheet or by message', 'Comentarios por la hoja o por mensaje') + '</li>'
      '<li>' + T('Suivi de ta force et de ta progression', 'Tracking of your strength and progress', 'Seguimiento de tu fuerza y de tu progreso') + '</li></ul></div></div>'
      '<p class="muted fnote">' + T('Durée : à partir de 2 mois pour chaque programme.', 'Duration: from 2 months for every program.', 'Duración: a partir de 2 meses en cada programa.') + '</p></section>')

def card(i, key, nom, sub, img, base, bullets, enm, esm, nom_en=None, nom_es=None):
    """bullets : liste de (fr,en,es). enm/esm : traductions du sous-titre."""
    av = base + 5
    sub_fr = T(sub[0], sub[1], sub[2]) if isinstance(sub, tuple) else sub
    pills = ('<span class="pill">' + T(f'{eur(base)} € sans suivi', f'{eur_en(base)} without follow-up', f'{eur(base)} € sin seguimiento') + '</span>'
             '<span class="pill pill-blue">' + T(f'{eur(av)} € avec suivi', f'{eur_en(av)} with follow-up', f'{eur(av)} € con seguimiento') + '</span>'
             '<span class="pill pill-grey">' + T('2 mois minimum', '2 months minimum', '2 meses mínimo') + '</span>')
    lis = ''.join('<li>' + T(*b) + '</li>' for b in bullets)
    m1, m2 = base / 2, av / 2
    extra = T(f'Mois supplémentaire sur demande : {eur(m1)} € sans suivi, {eur(m2)} € avec suivi.',
              f'Extra month on request: {eur_en(m1)} without follow-up, {eur_en(m2)} with follow-up.',
              f'Mes adicional bajo petición: {eur(m1)} € sin seguimiento, {eur(m2)} € con seguimiento.')
    # nom du produit "+ suivi" traduit pour la fenetre de paiement
    en_n = en0.get(key, key); es_n = es0.get(key, key)
    T(key + ' + suivi', en_n + ' + follow-up', es_n + ' + seguimiento')
    b1 = T(f'SANS SUIVI · {eur(base)} €', f'WITHOUT FOLLOW-UP · {eur_en(base)}', f'SIN SEGUIMIENTO · {eur(base)} €')
    b2 = T(f'AVEC SUIVI · {eur(av)} €', f'WITH FOLLOW-UP · {eur_en(av)}', f'CON SEGUIMIENTO · {eur(av)} €')
    more = T('EN SAVOIR PLUS', 'LEARN MORE', 'SABER MÁS')
    return (f'<article class="card prog"><img loading="lazy" src="assets/sub/{img}.webp" alt=""><div class="card-body"><span class="num">{i:02d}</span><h3>{nom}</h3>'
            f'<p class="muted">{sub_fr}</p><div class="pills">{pills}</div>'
            f'<details class="more"><summary>{more}</summary><div class="moreb"><ul class="packlist">{lis}</ul><p class="muted">{extra}</p></div></details>'
            f'<div class="buys"><a class="btn" type="button" data-pay="{key}" data-prix="{eur(base)} €">{b1}</a>'
            f'<a class="btn blue" type="button" data-pay="{key} + suivi" data-prix="{eur(av)} €">{b2}</a></div></div></article>')

def page(eyebrow, h1, notice, cards):
    out = f'<main class="wrap legal-page">\n  <div class="eyebrow">{eyebrow}</div>\n  <h1>{h1}</h1>\n'
    if notice: out += f'  <p class="notice">{notice}</p>\n'
    out += '  ' + formules() + '\n  <div class="grid progs" style="margin-top:26px">' + '\n'.join(cards) + '</div>\n</main>'
    return out

B = lambda fr, en, es: (fr, en, es)
# ---------- FORCE ----------
force = [
 card(1, 'Bench', 'BENCH', ('Développé couché', 'Bench press', 'Press de banca'), 'bench', 15, [
   B('Programme de 2 mois pour faire progresser ton développé couché.', 'A 2-month program to improve your bench press.', 'Un programa de 2 meses para mejorar tu press de banca.'),
   B('Variantes et renforcement : Larsen bench, triceps, épaules, dips.', 'Variations and strengthening work: Larsen bench, triceps, shoulders, dips.', 'Variantes y refuerzo: Larsen bench, tríceps, hombros, fondos.')], 0, 0),
 card(2, 'Deadlift', 'DEADLIFT', ('Soulevé de terre', 'Deadlift', 'Peso muerto'), 'deadlift', 15, [
   B('Programme de 2 mois pour faire progresser ton soulevé de terre.', 'A 2-month program to improve your deadlift.', 'Un programa de 2 meses para mejorar tu peso muerto.'),
   B('Renforcement des muscles qui interviennent dans le mouvement : dos, ischio-jambiers, fessiers, gainage.', 'Strengthening of the muscles used in the lift: back, hamstrings, glutes, core.', 'Refuerzo de los músculos que intervienen en el movimiento: espalda, isquiotibiales, glúteos, core.')], 0, 0),
 card(3, 'Squat', 'SQUAT', ('Squat', 'Squat', 'Sentadilla'), 'squat', 15, [
   B('Programme de 2 mois pour faire progresser ton squat.', 'A 2-month program to improve your squat.', 'Un programa de 2 meses para mejorar tu sentadilla.'),
   B('Renforcement des jambes, des fessiers et du gainage.', 'Strengthening of the legs, glutes and core.', 'Refuerzo de piernas, glúteos y core.')], 0, 0),
 card(4, 'Sbd Powerlifting', 'SBD POWERLIFTING', ('Squat, Bench et Deadlift réunis', 'Squat, Bench and Deadlift combined', 'Sentadilla, Banca y Peso muerto reunidos'), 'sbd', 20, [
   B('Squat, bench et deadlift dans un seul programme de 2 mois.', 'Squat, bench and deadlift in a single 2-month program.', 'Sentadilla, banca y peso muerto en un solo programa de 2 meses.'),
   B('Les trois mouvements sont répartis dans la semaine, avec leur travail complémentaire.', 'The three lifts are spread across the week, with their supporting work.', 'Los tres movimientos se reparten durante la semana, con su trabajo complementario.'),
   B('Moins cher que trois programmes séparés.', 'Cheaper than three separate programs.', 'Más barato que tres programas por separado.')], 0, 0),
]
n_force = T("Bench + Deadlift + Squat séparément : 45 € (60 € avec suivi). Réunis dans le SBD : 20 € (25 € avec suivi), soit plus de 55 % d'économie.",
            'Bench + Deadlift + Squat separately: €45 (€60 with follow-up). Combined in the SBD: €20 (€25 with follow-up), more than 55% off.',
            'Banca + Peso muerto + Sentadilla por separado: 45 € (60 € con seguimiento). Reunidos en el SBD: 20 € (25 € con seguimiento), más de un 55 % de ahorro.')
swap_main('force.html', page('PROGRAMMES', 'FORCE', n_force, force))

# ---------- DETENTE ----------
def pair(base, first, kind_fr, kind_en, kind_es, imgs, keys, names):
    s_fr, s_en, s_es = first
    out = []
    for n, (key, nom, img, sub, extra) in enumerate(zip(keys, names, imgs, [kind_fr, kind_en], [0, 0]), 1): pass
    return out
dt_b = lambda a: [
  B(f'Programme de 2 mois pour {a[0]}.', f'A 2-month program for {a[1]}.', f'Un programa de 2 meses para {a[2]}.'),
  B('2 à 3 séances par semaine.', '2 to 3 sessions per week.', '2 a 3 sesiones por semana.'),
  B(a[3], a[4], a[5])]
detente = [
 card(1, 'Détente en salle de musculation', 'EN SALLE DE MUSCULATION', ('Détente, puissance et explosivité en salle', 'Jumping ability, power and explosiveness in the gym', 'Salto, potencia y explosividad en el gimnasio'), 'detente-salle', 15,
   dt_b(('gagner en détente, en puissance et en explosivité', 'gaining jumping ability, power and explosiveness', 'ganar en salto, potencia y explosividad',
         'Exercices réalisés en salle de musculation.', 'Exercises done in the gym.', 'Ejercicios realizados en el gimnasio.')), 0, 0),
 card(2, 'Détente à la maison ou en extérieur', 'MAISON OU EXTÉRIEUR', ('Détente avec peu de matériel', 'Jumping ability with little equipment', 'Salto con poco material'), 'detente-ext', 15,
   dt_b(('gagner en détente, en puissance et en explosivité', 'gaining jumping ability, power and explosiveness', 'ganar en salto, potencia y explosividad',
         'Pensé pour la maison ou l\'extérieur, avec peu de matériel.', 'Designed for home or outdoors, with little equipment.', 'Pensado para casa o exterior, con poco material.')), 0, 0),
]
swap_main('detente.html', page('PROGRAMMES', 'DÉTENTE', None, detente))

# ---------- PERFORMANCE ----------
pf_b = lambda last: [
  B('Programme de 2 mois pour développer ta vitesse, ta puissance et tes qualités physiques.', 'A 2-month program to develop your speed, power and physical qualities.', 'Un programa de 2 meses para desarrollar tu velocidad, tu potencia y tus cualidades físicas.'),
  B('2 à 3 séances par semaine.', '2 to 3 sessions per week.', '2 a 3 sesiones por semana.'), last]
perf = [
 card(1, 'Performance en salle de musculation', 'EN SALLE DE MUSCULATION', ('Vitesse, puissance et qualités physiques', 'Speed, power and physical qualities', 'Velocidad, potencia y cualidades físicas'), 'perf-salle', 20,
   pf_b(B('Exercices réalisés en salle de musculation.', 'Exercises done in the gym.', 'Ejercicios realizados en el gimnasio.')), 0, 0),
 card(2, 'Performance à la maison ou en extérieur', 'MAISON OU EXTÉRIEUR', ('Vitesse et explosivité sans salle', 'Speed and explosiveness without a gym', 'Velocidad y explosividad sin gimnasio'), 'perf-ext', 20,
   pf_b(B('Pensé pour la maison ou l\'extérieur, avec peu de matériel.', 'Designed for home or outdoors, with little equipment.', 'Pensado para casa o exterior, con poco material.')), 0, 0),
]
swap_main('performance-athletique.html', page('PROGRAMMES', 'PERFORMANCE ATHLÉTIQUE', None, perf))

# ---------- MUSCULATION ----------
mu = [
 card(1, '3 Fois Full', '3 FOIS FULL', ('Full body, 2 à 3 séances par semaine', 'Full body, 2 to 3 sessions per week', 'Full body, 2 a 3 sesiones por semana'), 'full', 15, [
   B('Tout le corps travaillé à chaque séance.', 'The whole body is trained in every session.', 'Todo el cuerpo se trabaja en cada sesión.'),
   B('2 à 3 séances par semaine.', '2 to 3 sessions per week.', '2 a 3 sesiones por semana.')], 0, 0),
 card(2, 'Gym Bro', 'GYM BRO', ('5 séances par semaine', '5 sessions per week', '5 sesiones por semana'), 'gymbro', 15, [
   B('5 séances par semaine.', '5 sessions per week.', '5 sesiones por semana.'),
   B('Lundi haut, mardi haut, mercredi jambes, jeudi repos, vendredi full body, samedi bas.', 'Monday upper body, Tuesday upper body, Wednesday legs, Thursday rest, Friday full body, Saturday lower body.', 'Lunes tren superior, martes tren superior, miércoles piernas, jueves descanso, viernes full body, sábado tren inferior.')], 0, 0),
 card(3, 'Le Double Double', 'LE DOUBLE DOUBLE', ('Deux séances haut, deux séances bas', 'Two upper-body sessions, two lower-body sessions', 'Dos sesiones de tren superior, dos de inferior'), 'double', 15, [
   B('4 séances par semaine.', '4 sessions per week.', '4 sesiones por semana.'),
   B('Deux séances pour le haut du corps et deux séances pour le bas du corps.', 'Two sessions for the upper body and two for the lower body.', 'Dos sesiones para el tren superior y dos para el inferior.')], 0, 0),
 card(4, 'Jambe De Fer', 'JAMBE DE FER', ('3 à 4 séances de jambes par semaine', '3 to 4 leg sessions per week', '3 a 4 sesiones de piernas por semana'), 'jambe', 15, [
   B('3 à 4 séances de jambes par semaine.', '3 to 4 leg sessions per week.', '3 a 4 sesiones de piernas por semana.'),
   B('Pour développer les jambes en priorité.', 'To build the legs first and foremost.', 'Para desarrollar las piernas como prioridad.')], 0, 0),
 card(5, 'Popeye', 'POPEYE', ('3 à 4 séances haut du corps uniquement', '3 to 4 upper-body-only sessions', '3 a 4 sesiones solo de tren superior'), 'popeye', 15, [
   B('3 à 4 séances par semaine, uniquement pour le haut du corps.', '3 to 4 sessions per week, upper body only.', '3 a 4 sesiones por semana, solo tren superior.'),
   B('Pour développer pecs, dos, épaules et bras.', 'To build chest, back, shoulders and arms.', 'Para desarrollar pecho, espalda, hombros y brazos.')], 0, 0),
 card(6, 'Home Body', 'HOME BODY', ('Programme à faire à la maison', 'A program to do at home', 'Un programa para hacer en casa'), 'homebody', 15, [
   B('Pensé pour s\'entraîner à la maison.', 'Designed for training at home.', 'Pensado para entrenar en casa.'),
   B('Tous les niveaux : débutants comme confirmés.', 'All levels: beginners and experienced alike.', 'Todos los niveles: principiantes y experimentados.')], 0, 0),
]
swap_main('musculation.html', page('PROGRAMMES', 'MUSCULATION', None, mu))

# ---------- NUTRITION ----------
nut = '<main class="wrap legal-page">\n<div class="eyebrow">' + T('PROGRAMME 05', 'PROGRAM 05', 'PROGRAMA 05') + '</div>\n<h1>NUTRITION</h1>\n' \
 '<div class="pills" style="margin:16px 0"><span class="pill">' + T('5 € / mois avec un programme', '€5 / month with a program', '5 € / mes con un programa') + '</span><span class="pill pill-blue">' + T('10 € / mois sans programme', '€10 / month without a program', '10 € / mes sin programa') + '</span></div>\n' \
 '<p>' + T("Pour le prix d'un milkshake, tu investis dans ton corps.", "For the price of a milkshake, you invest in your body.", "Por el precio de un batido, inviertes en tu cuerpo.") + '</p>\n' \
 '<p class="muted">' + T("5 € par mois si tu prends aussi un de mes programmes, 10 € par mois si tu prends la nutrition seule.", "€5 per month if you also take one of my programs, €10 per month for nutrition on its own.", "5 € al mes si también tomas uno de mis programas, 10 € al mes si tomas solo la nutrición.") + '</p>\n<ul class="packlist">\n'
for b in [
 B('Un appel chaque semaine pour faire le point', 'A call every week to review your progress', 'Una llamada cada semana para hacer balance'),
 B('Un tableau pour suivre ton poids', 'A table to track your weight', 'Una tabla para seguir tu peso'),
 B('Calories et macronutriments adaptés à ton objectif', 'Calories and macronutrients adapted to your goal', 'Calorías y macronutrientes adaptados a tu objetivo'),
 B('Chaque jour, tu m’envoies une photo de tes plats et je te donne mon avis', 'Every day, you send me a photo of your meals and I give you my feedback', 'Cada día me envías una foto de tus platos y te doy mi opinión'),
 B('Un suivi permanent entre les appels', 'Ongoing follow-up between calls', 'Un seguimiento permanente entre llamadas'),
 B('Objectifs : prise de muscle, perte de gras, sèche, recomposition corporelle', 'Goals: muscle gain, fat loss, cutting, body recomposition', 'Objetivos: ganar músculo, perder grasa, definición, recomposición corporal'),
 B('Une autre demande ? Écris-moi, on en discute', 'Something else in mind? Message me and we’ll talk about it', '¿Otra petición? Escríbeme y lo hablamos')]:
    nut += '<li>' + T(*b) + '</li>\n'
nut += '</ul>\n<div class="actions05" style="border-top:0;padding-top:0"><button class="btn" type="button" data-pay="Nutrition seul" data-prix="10 €">' + T('PAYER 10 € / MOIS (SANS PROGRAMME)', 'PAY €10 / MONTH (WITHOUT A PROGRAM)', 'PAGAR 10 € / MES (SIN PROGRAMA)') + '</button><button class="btn blue" type="button" data-pay="Nutrition avec accompagnement" data-prix="5 €">' + T('PAYER 5 € / MOIS (AVEC UN PROGRAMME)', 'PAY €5 / MONTH (WITH A PROGRAM)', 'PAGAR 5 € / MES (CON UN PROGRAMA)') + '</button></div>\n\n</main>'
swap_main('nutrition.html', nut)

# ---------- bandeau "creation de site" ----------
def site_band():
    return ('<section class="ctaband siteband"><div><h2>' + T('Tu veux un site comme celui-ci ?', 'Want a website like this one?', '¿Quieres una web como esta?') + '</h2><p>' +
            T("Ce site, je l'ai créé 100 % moi-même. Apprends à le faire avec ma formation PDF, ou fais-le créer sur devis.", 'I built this site 100% myself. Learn to do it with my PDF course, or have it built for you on quote.', 'Esta web la creé yo mismo al 100 %. Aprende a hacerlo con mi formación en PDF, o encárgamela con presupuesto.') + '</p></div><div class="ctabtns"><a class="btn" href="creation-site.html">' +
            T('VOIR LA CRÉATION DE SITE', 'SEE WEBSITE CREATION', 'VER CREACIÓN DE WEB') + '</a></div></section>')

# ---------- PROGRAMMES : 5 cartes + bandeau ----------
s = rd('programmes.html')
s = re.sub(r'\s*<article class="card"><img src="assets/creation-site.webp" alt="Création de site">.*?</article>', '', s, flags=re.S)
s = s.replace('<span class="num">05</span><h3>NUTRITION', '<span class="num">05</span><h3>NUTRITION')
s = s.replace('<article class="card"><img src="assets/nutrition.webp"', '<article class="card wide"><img src="assets/nutrition.webp"')
if 'siteband' not in s:
    s = s.replace('<section class="ctaband">', site_band() + '\n\n<section class="ctaband">', 1)
wr('programmes.html', s)

# ---------- PARCOURS : paragraphe + bandeau ----------
s = rd('parcours.html')
para = '<p>' + T("Ce site, je l'ai aussi créé moi-même, à 100 %, avec l'intelligence artificielle. Si tu veux un site comme celui-ci, je peux t'apprendre à le faire ou le créer pour toi.", 'I also built this website myself, 100%, with artificial intelligence. If you want a site like this one, I can teach you how to do it or build it for you.', 'Esta web también la creé yo mismo, al 100 %, con inteligencia artificial. Si quieres una web como esta, puedo enseñarte a hacerla o crearla por ti.') + '</p>\n'
if 'créé moi-même, à 100' not in s:
    s = s.replace('<div class="mediaslot" data-media="parcours"></div>', para + '<div class="mediaslot" data-media="parcours"></div>', 1)
if 'siteband' not in s:
    s = s.replace('<section class="ctaband">', site_band() + '\n\n<section class="ctaband">', 1)
wr('parcours.html', s)

# ---------- CREATION DE SITE ----------
s = rd('creation-site.html')
s = s.replace('<div class="eyebrow">PROGRAMMES</div>', '<div class="eyebrow">' + T('TON SITE WEB', 'YOUR WEBSITE', 'TU WEB') + '</div>')
intro = ('<section class="ctaband siteband"><div><h2>' + T('Ce site, je l’ai créé 100 % moi-même', 'I built this site 100% myself', 'Esta web la creé yo mismo al 100 %') + '</h2><p>' +
         T('Tu veux un site comme celui-ci ? Apprends à le créer avec ma formation PDF, ou je le crée pour toi.', 'Want a site like this one? Learn to build it with my PDF course, or I build it for you.', '¿Quieres una web como esta? Aprende a crearla con mi formación en PDF, o la creo yo por ti.') +
         '</p></div><div class="ctabtns"><a class="btn" target="_blank" rel="noopener" href="https://wa.me/33767927163?text=Bonjour%20Victor%2C%20je%20voudrais%20un%20devis%20pour%20la%20cr%C3%A9ation%20de%20mon%20site.">' +
         T('DEMANDER UN DEVIS', 'ASK FOR A QUOTE', 'PEDIR PRESUPUESTO') + '</a><a class="btn alt" href="#formation">' + T('VOIR LA FORMATION PDF', 'SEE THE PDF COURSE', 'VER LA FORMACIÓN EN PDF') + '</a></div></section>\n')
if 'siteband' not in s:
    s = s.replace('<div class="grid sitecards"', intro + '  <div class="grid sitecards"', 1)
    s = s.replace('<article class="card"><img src="assets/creation-site.webp" alt="Formation', '<article class="card" id="formation"><img src="assets/creation-site.webp" alt="Formation', 1)
wr('creation-site.html', s)

# ---------- NAV + FOOTER (toutes les pages FR) ----------
lab = T('Création de site', 'Website creation', 'Creación de web')
for f in os.listdir(SITE):
    if not f.endswith('.html'): continue
    s = rd(f); o = s
    if 'href="creation-site.html">' + lab + '</a><a href="espace.html"' not in s:
        s = s.replace('<a href="outils.html">Outils</a>', '<a href="outils.html">Outils</a><a href="creation-site.html">' + lab + '</a>', 1)
    if '<a href="cookies.html">Cookies</a><a href="creation-site.html">' not in s:
        s = s.replace('<a href="cookies.html">Cookies</a></div><div class="fsoc">', '<a href="cookies.html">Cookies</a><a href="creation-site.html">' + lab + '</a></div><div class="fsoc">', 1)
    if s != o: wr(f, s)

# ---------- traductions -> extras.py ----------
mark = '# ==== v47 (genere) ===='
ex = open('extras.py', encoding='utf8').read()
if mark in ex: ex = ex[:ex.index(mark)]
seen = set(); lines = []
for fr, e, sp in TR:
    if fr in seen: continue
    seen.add(fr); lines.append('(' + json.dumps(fr, ensure_ascii=False) + ',' + json.dumps(e, ensure_ascii=False) + ',' + json.dumps(sp, ensure_ascii=False) + '),')
ex = ex.rstrip('\n') + '\n' + mark + '\nEXACT += [\n' + '\n'.join(lines) + '\n]\n'
open('extras.py', 'w', encoding='utf8').write(ex)
print('ok', len(TR), 'traductions')
